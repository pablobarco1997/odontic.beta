<?php
$name='TharLon';
$type='TTF';
$desc=array (
  'CapHeight' => 688,
  'XHeight' => 528,
  'FontBBox' => '[-1076 -426 2339 1026]',
  'Flags' => 4,
  'Ascent' => 1026,
  'Descent' => -426,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 318,
);
$unitsPerEm=1000;
$up=-405;
$ut=50;
$strp=250;
$strs=50;
$ttffile='C:/wamp64/www/MPDF_6_0/mpdf60/ttfonts/Tharlon-Regular.ttf';
$TTCfontID='0';
$originalsize=353228;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='tharlon';
$panose=' 0 0 2 0 5 3 0 0 0 2 0 3';
$haskerninfo=true;
$haskernGPOS=true;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 1026, -426, 0
// usWinAscent/usWinDescent = 1026, -426
// hhea Ascent/Descent/LineGap = 1026, -426, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'mymr' => 'DFLT ',
);
$GSUBFeatures=array (
  'mymr' => 
  array (
    'DFLT' => 
    array (
      'clig' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
        9 => 9,
        10 => 10,
        11 => 11,
        12 => 12,
        13 => 13,
        14 => 14,
        15 => 15,
        16 => 16,
        17 => 17,
        18 => 18,
        19 => 19,
        20 => 20,
        21 => 22,
        22 => 23,
        23 => 24,
        24 => 25,
        25 => 26,
        26 => 27,
        27 => 28,
        28 => 29,
        29 => 30,
        30 => 31,
        31 => 32,
        32 => 33,
        33 => 34,
        34 => 35,
        35 => 36,
        36 => 37,
        37 => 38,
        38 => 39,
        39 => 40,
        40 => 41,
        41 => 42,
        42 => 43,
        43 => 44,
        44 => 45,
        45 => 46,
        46 => 47,
        47 => 48,
        48 => 49,
        49 => 50,
        50 => 52,
        51 => 53,
        52 => 54,
        53 => 55,
        54 => 56,
        55 => 57,
        56 => 58,
        57 => 59,
        58 => 60,
        59 => 61,
        60 => 62,
        61 => 63,
        62 => 64,
        63 => 65,
        64 => 66,
        65 => 67,
        66 => 68,
        67 => 69,
        68 => 70,
        69 => 71,
        70 => 72,
        71 => 73,
        72 => 74,
        73 => 75,
        74 => 76,
        75 => 77,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282188,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282262,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282288,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282322,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282440,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282488,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282516,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282654,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282680,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282734,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 282974,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 283008,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 283040,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 283068,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 283094,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 283340,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 283372,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 283414,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 284032,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 284194,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 284550,
      1 => 284568,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 5,
    'Subtables' => 
    array (
      0 => 284604,
      1 => 284622,
      2 => 284642,
      3 => 284672,
      4 => 284712,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 284856,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 284900,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 285222,
      1 => 285490,
      2 => 285510,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 285542,
      1 => 285560,
      2 => 285580,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 285778,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 285806,
      1 => 286104,
    ),
    'MarkFilteringSet' => '',
  ),
  28 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 286138,
    ),
    'MarkFilteringSet' => '',
  ),
  29 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 286396,
    ),
    'MarkFilteringSet' => '',
  ),
  30 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 286538,
      1 => 286556,
    ),
    'MarkFilteringSet' => '',
  ),
  31 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 286584,
    ),
    'MarkFilteringSet' => '',
  ),
  32 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 6,
    'Subtables' => 
    array (
      0 => 286628,
      1 => 286736,
      2 => 286762,
      3 => 286794,
      4 => 286814,
      5 => 286832,
    ),
    'MarkFilteringSet' => '',
  ),
  33 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 21,
    'Subtables' => 
    array (
      0 => 286904,
      1 => 286930,
      2 => 286952,
      3 => 286972,
      4 => 286996,
      5 => 287016,
      6 => 287038,
      7 => 287060,
      8 => 287106,
      9 => 287128,
      10 => 287148,
      11 => 287168,
      12 => 287200,
      13 => 287220,
      14 => 287248,
      15 => 287268,
      16 => 287294,
      17 => 287314,
      18 => 287342,
      19 => 287362,
      20 => 287384,
    ),
    'MarkFilteringSet' => '',
  ),
  34 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 15,
    'Subtables' => 
    array (
      0 => 287446,
      1 => 287472,
      2 => 287492,
      3 => 287520,
      4 => 287540,
      5 => 287560,
      6 => 287580,
      7 => 287600,
      8 => 287620,
      9 => 287646,
      10 => 287666,
      11 => 287700,
      12 => 287724,
      13 => 287756,
      14 => 287776,
    ),
    'MarkFilteringSet' => '',
  ),
  35 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 287820,
    ),
    'MarkFilteringSet' => '',
  ),
  36 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288132,
    ),
    'MarkFilteringSet' => '',
  ),
  37 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288158,
    ),
    'MarkFilteringSet' => '',
  ),
  38 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288184,
    ),
    'MarkFilteringSet' => '',
  ),
  39 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288212,
    ),
    'MarkFilteringSet' => '',
  ),
  40 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288240,
    ),
    'MarkFilteringSet' => '',
  ),
  41 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288266,
    ),
    'MarkFilteringSet' => '',
  ),
  42 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288292,
    ),
    'MarkFilteringSet' => '',
  ),
  43 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288320,
    ),
    'MarkFilteringSet' => '',
  ),
  44 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288348,
    ),
    'MarkFilteringSet' => '',
  ),
  45 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288374,
    ),
    'MarkFilteringSet' => '',
  ),
  46 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288400,
    ),
    'MarkFilteringSet' => '',
  ),
  47 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288428,
    ),
    'MarkFilteringSet' => '',
  ),
  48 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288462,
    ),
    'MarkFilteringSet' => '',
  ),
  49 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288488,
    ),
    'MarkFilteringSet' => '',
  ),
  50 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288516,
    ),
    'MarkFilteringSet' => '',
  ),
  51 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 7,
    'Subtables' => 
    array (
      0 => 288554,
      1 => 288574,
      2 => 288594,
      3 => 288614,
      4 => 288634,
      5 => 288696,
      6 => 288768,
    ),
    'MarkFilteringSet' => '',
  ),
  52 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288800,
    ),
    'MarkFilteringSet' => '',
  ),
  53 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288826,
    ),
    'MarkFilteringSet' => '',
  ),
  54 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 288852,
    ),
    'MarkFilteringSet' => '',
  ),
  55 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 290152,
    ),
    'MarkFilteringSet' => '',
  ),
  56 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 290214,
      1 => 290240,
      2 => 290258,
    ),
    'MarkFilteringSet' => '',
  ),
  57 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 290288,
      1 => 290394,
    ),
    'MarkFilteringSet' => '',
  ),
  58 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 290426,
      1 => 290444,
      2 => 290464,
    ),
    'MarkFilteringSet' => '',
  ),
  59 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 290594,
      1 => 290612,
      2 => 290632,
      3 => 290652,
    ),
    'MarkFilteringSet' => '',
  ),
  60 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 290784,
    ),
    'MarkFilteringSet' => '',
  ),
  61 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 15,
    'Subtables' => 
    array (
      0 => 290916,
      1 => 290934,
      2 => 290970,
      3 => 290996,
      4 => 291014,
      5 => 291064,
      6 => 291098,
      7 => 291124,
      8 => 291144,
      9 => 291162,
      10 => 291224,
      11 => 291242,
      12 => 291306,
      13 => 291338,
      14 => 291376,
    ),
    'MarkFilteringSet' => '',
  ),
  62 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 291410,
    ),
    'MarkFilteringSet' => '',
  ),
  63 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 291456,
      1 => 291486,
      2 => 291518,
      3 => 291630,
    ),
    'MarkFilteringSet' => '',
  ),
  64 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 291670,
    ),
    'MarkFilteringSet' => '',
  ),
  65 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 291696,
    ),
    'MarkFilteringSet' => '',
  ),
  66 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 291724,
    ),
    'MarkFilteringSet' => '',
  ),
  67 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 291756,
    ),
    'MarkFilteringSet' => '',
  ),
  68 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 291788,
    ),
    'MarkFilteringSet' => '',
  ),
  69 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 291820,
    ),
    'MarkFilteringSet' => '',
  ),
  70 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 291852,
    ),
    'MarkFilteringSet' => '',
  ),
  71 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 295914,
    ),
    'MarkFilteringSet' => '',
  ),
  72 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 16,
    'Subtables' => 
    array (
      0 => 296060,
      1 => 296088,
      2 => 296116,
      3 => 296144,
      4 => 296172,
      5 => 296200,
      6 => 296228,
      7 => 296256,
      8 => 296284,
      9 => 296312,
      10 => 296340,
      11 => 296368,
      12 => 296396,
      13 => 296416,
      14 => 296446,
      15 => 296474,
    ),
    'MarkFilteringSet' => '',
  ),
  73 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296508,
    ),
    'MarkFilteringSet' => '',
  ),
  74 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296534,
    ),
    'MarkFilteringSet' => '',
  ),
  75 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296572,
    ),
    'MarkFilteringSet' => '',
  ),
  76 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296598,
    ),
    'MarkFilteringSet' => '',
  ),
  77 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296630,
    ),
    'MarkFilteringSet' => '',
  ),
  78 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296678,
    ),
    'MarkFilteringSet' => '',
  ),
  79 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296704,
    ),
    'MarkFilteringSet' => '',
  ),
  80 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296724,
    ),
    'MarkFilteringSet' => '',
  ),
  81 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296798,
    ),
    'MarkFilteringSet' => '',
  ),
  82 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296818,
    ),
    'MarkFilteringSet' => '',
  ),
  83 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297256,
    ),
    'MarkFilteringSet' => '',
  ),
  84 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296880,
    ),
    'MarkFilteringSet' => '',
  ),
  85 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296900,
    ),
    'MarkFilteringSet' => '',
  ),
  86 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296918,
    ),
    'MarkFilteringSet' => '',
  ),
  87 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296964,
    ),
    'MarkFilteringSet' => '',
  ),
  88 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 296984,
    ),
    'MarkFilteringSet' => '',
  ),
  89 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297010,
    ),
    'MarkFilteringSet' => '',
  ),
  90 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297040,
    ),
    'MarkFilteringSet' => '',
  ),
  91 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297230,
    ),
    'MarkFilteringSet' => '',
  ),
  92 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297256,
    ),
    'MarkFilteringSet' => '',
  ),
  93 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297276,
    ),
    'MarkFilteringSet' => '',
  ),
  94 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297314,
    ),
    'MarkFilteringSet' => '',
  ),
  95 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297334,
    ),
    'MarkFilteringSet' => '',
  ),
  96 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297360,
    ),
    'MarkFilteringSet' => '',
  ),
  97 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297380,
    ),
    'MarkFilteringSet' => '',
  ),
  98 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297400,
    ),
    'MarkFilteringSet' => '',
  ),
  99 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297426,
    ),
    'MarkFilteringSet' => '',
  ),
  100 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297520,
    ),
    'MarkFilteringSet' => '',
  ),
  101 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297540,
    ),
    'MarkFilteringSet' => '',
  ),
  102 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297570,
    ),
    'MarkFilteringSet' => '',
  ),
  103 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297590,
    ),
    'MarkFilteringSet' => '',
  ),
  104 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297604,
    ),
    'MarkFilteringSet' => '',
  ),
  105 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297624,
    ),
    'MarkFilteringSet' => '',
  ),
  106 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297650,
    ),
    'MarkFilteringSet' => '',
  ),
  107 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 297928,
    ),
    'MarkFilteringSet' => '',
  ),
  108 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 298206,
    ),
    'MarkFilteringSet' => '',
  ),
  109 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 298616,
    ),
    'MarkFilteringSet' => '',
  ),
  110 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 299026,
    ),
    'MarkFilteringSet' => '',
  ),
  111 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 299474,
    ),
    'MarkFilteringSet' => '',
  ),
  112 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 299832,
    ),
    'MarkFilteringSet' => '',
  ),
  113 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 300362,
    ),
    'MarkFilteringSet' => '',
  ),
  114 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 300892,
    ),
    'MarkFilteringSet' => '',
  ),
  115 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 301862,
    ),
    'MarkFilteringSet' => '',
  ),
  116 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 302628,
    ),
    'MarkFilteringSet' => '',
  ),
  117 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 304096,
    ),
    'MarkFilteringSet' => '',
  ),
  118 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305238,
    ),
    'MarkFilteringSet' => '',
  ),
  119 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305266,
    ),
    'MarkFilteringSet' => '',
  ),
  120 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305292,
    ),
    'MarkFilteringSet' => '',
  ),
  121 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305312,
    ),
    'MarkFilteringSet' => '',
  ),
  122 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 305332,
    ),
    'MarkFilteringSet' => '',
  ),
  123 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306404,
    ),
    'MarkFilteringSet' => '',
  ),
  124 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306818,
    ),
    'MarkFilteringSet' => '',
  ),
  125 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306844,
    ),
    'MarkFilteringSet' => '',
  ),
  126 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306864,
    ),
    'MarkFilteringSet' => '',
  ),
  127 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306884,
    ),
    'MarkFilteringSet' => '',
  ),
  128 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306904,
    ),
    'MarkFilteringSet' => '',
  ),
  129 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306924,
    ),
    'MarkFilteringSet' => '',
  ),
  130 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306954,
    ),
    'MarkFilteringSet' => '',
  ),
  131 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 306974,
    ),
    'MarkFilteringSet' => '',
  ),
  132 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 307332,
    ),
    'MarkFilteringSet' => '',
  ),
  133 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 307938,
    ),
    'MarkFilteringSet' => '',
  ),
  134 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 308872,
    ),
    'MarkFilteringSet' => '',
  ),
  135 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 309806,
    ),
    'MarkFilteringSet' => '',
  ),
  136 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 310740,
    ),
    'MarkFilteringSet' => '',
  ),
  137 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 311780,
    ),
    'MarkFilteringSet' => '',
  ),
  138 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 311814,
    ),
    'MarkFilteringSet' => '',
  ),
  139 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 311864,
    ),
    'MarkFilteringSet' => '',
  ),
  140 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 311898,
    ),
    'MarkFilteringSet' => '',
  ),
  141 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 311916,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'mymr' => 'DFLT ',
);
$GPOSFeatures=array (
  'mymr' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 280986,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281056,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281096,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281368,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281402,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281448,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281488,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281522,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 8,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281568,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281608,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281634,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 281676,
    ),
    'MarkFilteringSet' => '',
  ),
);
$kerninfo=array (
  57499 => 
  array (
    57486 => 139,
  ),
);
?>