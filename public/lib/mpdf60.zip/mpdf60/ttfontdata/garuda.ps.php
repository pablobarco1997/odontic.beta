<?php 
$originalsize=54956;
?>