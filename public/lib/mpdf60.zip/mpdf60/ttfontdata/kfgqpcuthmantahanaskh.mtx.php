<?php
$name='KFGQPCUthmanTahaNaskh';
$type='TTF';
$desc=array (
  'CapHeight' => 719,
  'XHeight' => 339,
  'FontBBox' => '[-126 -531 1190 1064]',
  'Flags' => 4,
  'Ascent' => 1064,
  'Descent' => -531,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 0,
);
$unitsPerEm=2048;
$up=-341;
$ut=50;
$strp=250;
$strs=50;
$ttffile='C:/wamp64/www/MPDF_6_0/mpdf60/ttfonts/Uthman.otf';
$TTCfontID='0';
$originalsize=172980;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='kfgqpcuthmantahanaskh';
$panose=' 0 0 2 0 0 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 1123, -562, 0
// usWinAscent/usWinDescent = 1123, -562
// hhea Ascent/Descent/LineGap = 1123, -562, 0
$useOTL=255;
$rtlPUAstr='\x{0E007}-\x{0E015}\x{0E017}-\x{0E045}\x{0E047}-\x{0E054}\x{0E056}-\x{0E0A7}\x{0E0A9}-\x{0E0C0}\x{0E0C2}-\x{0E0F0}\x{0E0F2}-\x{0E13C}\x{0E13E}-\x{0E143}\x{0E146}-\x{0E153}';
$GSUBScriptLang=array (
  'arab' => 'DFLT ',
);
$GSUBFeatures=array (
  'arab' => 
  array (
    'DFLT' => 
    array (
      'liga' => 
      array (
        0 => 0,
        1 => 13,
        2 => 14,
        3 => 23,
        4 => 24,
        5 => 25,
        6 => 26,
        7 => 27,
        8 => 28,
      ),
      'init' => 
      array (
        0 => 1,
      ),
      'medi' => 
      array (
        0 => 2,
      ),
      'fina' => 
      array (
        0 => 3,
      ),
      'calt' => 
      array (
        0 => 4,
        1 => 5,
        2 => 6,
        3 => 7,
        4 => 8,
        5 => 9,
        6 => 10,
        7 => 11,
        8 => 12,
        9 => 15,
        10 => 16,
        11 => 17,
        12 => 18,
        13 => 19,
        14 => 20,
        15 => 21,
        16 => 22,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 138438,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 138524,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 138666,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 138808,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 6,
    'Flag' => 9,
    'SubtableCount' => 12,
    'Subtables' => 
    array (
      0 => 138932,
      1 => 138954,
      2 => 138978,
      3 => 139002,
      4 => 139026,
      5 => 139052,
      6 => 139078,
      7 => 139106,
      8 => 139134,
      9 => 139158,
      10 => 139182,
      11 => 139208,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 141662,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 141708,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 141784,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 4,
    'Subtables' => 
    array (
      0 => 141832,
      1 => 141856,
      2 => 141876,
      3 => 141898,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 7,
    'Subtables' => 
    array (
      0 => 142248,
      1 => 142268,
      2 => 142288,
      3 => 142306,
      4 => 142326,
      5 => 142344,
      6 => 142364,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 142542,
      1 => 142560,
      2 => 142580,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 142916,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 6,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 142986,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 143172,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 143564,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 6,
    'Flag' => 9,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 143918,
      1 => 143936,
      2 => 143954,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 144060,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 6,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 144250,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 6,
    'Flag' => 9,
    'SubtableCount' => 5,
    'Subtables' => 
    array (
      0 => 144354,
      1 => 144374,
      2 => 144394,
      3 => 144414,
      4 => 144434,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 6,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 144924,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 5,
    'Subtables' => 
    array (
      0 => 145058,
      1 => 145084,
      2 => 145108,
      3 => 145132,
      4 => 145154,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 11,
    'Subtables' => 
    array (
      0 => 146020,
      1 => 146040,
      2 => 146062,
      3 => 146086,
      4 => 146106,
      5 => 146128,
      6 => 146152,
      7 => 146170,
      8 => 146190,
      9 => 146212,
      10 => 146232,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 147038,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 147084,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 147278,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 147722,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 148584,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 148992,
    ),
    'MarkFilteringSet' => '',
  ),
  28 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149182,
    ),
    'MarkFilteringSet' => '',
  ),
  29 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149330,
    ),
    'MarkFilteringSet' => '',
  ),
  30 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149356,
    ),
    'MarkFilteringSet' => '',
  ),
  31 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149394,
    ),
    'MarkFilteringSet' => '',
  ),
  32 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149412,
    ),
    'MarkFilteringSet' => '',
  ),
  33 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149426,
    ),
    'MarkFilteringSet' => '',
  ),
  34 => 
  array (
    'Type' => 4,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149440,
    ),
    'MarkFilteringSet' => '',
  ),
  35 => 
  array (
    'Type' => 1,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149710,
    ),
    'MarkFilteringSet' => '',
  ),
  36 => 
  array (
    'Type' => 1,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149728,
    ),
    'MarkFilteringSet' => '',
  ),
  37 => 
  array (
    'Type' => 1,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149828,
    ),
    'MarkFilteringSet' => '',
  ),
  38 => 
  array (
    'Type' => 1,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149910,
    ),
    'MarkFilteringSet' => '',
  ),
  39 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 149944,
    ),
    'MarkFilteringSet' => '',
  ),
  40 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 150042,
    ),
    'MarkFilteringSet' => '',
  ),
  41 => 
  array (
    'Type' => 1,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 150060,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'arab' => 'DFLT ',
);
$GPOSFeatures=array (
  'arab' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
        3 => 3,
        4 => 4,
        5 => 5,
        6 => 6,
        7 => 7,
        8 => 8,
        9 => 9,
        10 => 10,
        11 => 11,
        12 => 12,
      ),
      'curs' => 
      array (
        0 => 13,
        1 => 14,
        2 => 15,
      ),
      'mkmk' => 
      array (
        0 => 16,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 150348,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 151340,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 151534,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 151732,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 152180,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 152722,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 153186,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 153570,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 154382,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 155612,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 156070,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 5,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 156408,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 4,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 156750,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 3,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 156968,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 3,
    'Flag' => 9,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157558,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 3,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157812,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 6,
    'Flag' => 1,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157988,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>