<?php 
$originalsize=63752;
?>