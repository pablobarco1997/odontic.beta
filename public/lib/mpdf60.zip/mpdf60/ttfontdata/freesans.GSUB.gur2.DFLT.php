<?php

$rtlSUB = array();
$finals = '';
$rphf = array (
);
$half = array (
);
$pref = array (
);
$blwf = array (
  2608 => 57985,
  2613 => 57986,
  2617 => 57987,
);
$pstf = array (
  2607 => 57988,
);

 
?>